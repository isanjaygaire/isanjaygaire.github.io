<?php

class counter_shortcode {

	public function register_shortcode($shortcodeName) {
		function shortcode_counter($atts, $content = null) {

            if (!isset($compile)) {$compile='';}

			extract( shortcode_atts( array(
                'heading_alignment' => 'left',
                'heading_size' => $GLOBALS["pbconfig"]['default_heading_in_module'],
                'heading_color' => '',
                'heading_text' => '',
				'stat_title' => '',
				'stat_text' => '',
			), $atts ) );

			wp_enqueue_script('gt3_waypoint_js', get_template_directory_uri() . '/js/waypoint.js', array(), false, true);

            #heading
            if (strlen($heading_color)>0) {$custom_color = "color:#{$heading_color};";}
            if (strlen($heading_text)>0) {
                $compile .= "<div class='bg_title'><".$heading_size." style='".(isset($custom_color) ? $custom_color : '') . ((strlen($heading_alignment) > 0 && $heading_alignment !== 'left') ? 'text-align:'.$heading_alignment.';' : '')."' class='headInModule'>{$heading_text}</".$heading_size."></div>";
            }

            $compile .= "		
			<div class='module_content shortcode_counter'>
				<div class='counter_wrapper'>
					<div class='counter_content'>
						<div class='stat_count_wrapper'>						
							<h3 class='stat_count' data-count='".$content."'>0</h3>
						</div>
						<div class='counter_body'>
							<h6 class='counter_title'>".$stat_title."</h6>
							<div class='counter_text'>".$stat_text."</div>
							<div class='stat_temp'></div>
						</div>
					</div>
				</div>
			</div>
			";

            $GLOBALS['showOnlyOneTimeJS']['counter_js'] = "
			<script>
				jQuery(document).ready(function($) {
					if (myWindow.width() > 760) {						
						jQuery('.shortcode_counter').each(function(){							
							if (jQuery(this).offset().top < myWindow.height()) {
								if (!jQuery(this).hasClass('done')) {
									var set_count = jQuery(this).find('.stat_count').attr('data-count');
									jQuery(this).find('.stat_temp').stop().animate({width: set_count}, {duration: 3000, step: function(now) {
											var data = Math.floor(now),
											text_data = data.toString(),
											cut_data = '',
											cut_data2 = '';
											if (text_data.length > 3 && text_data.length < 7) {
												cut_data = text_data.substr(-3);
												cut_data2 = text_data.substr(0, text_data.length-3);
												show_data = cut_data2 + ' ' + cut_data;
											} 
											if (text_data.length > 6 && text_data.length < 10) {
												cut_data = text_data.substr(-3);
												if (text_data.length == 9) {
													cut_data1 = text_data.substr(text_data.length-6, text_data.length-6);
												} else if (text_data.length == 8) {
													cut_data1 = text_data.substr(text_data.length-6, text_data.length-5);
												} else {
													cut_data1 = text_data.substr(text_data.length-6, text_data.length-4);												
												}
												cut_data2 = text_data.substr(0, text_data.length-6);
												console.log('length: '+text_data.length +';'+cut_data2 +';'+ cut_data1 +';'+ cut_data);
												show_data = cut_data2 + ' ' + cut_data1 + ' ' + cut_data;												
											} 
											if (text_data.length < 4) {												
												show_data = text_data.substr(-3);
											}
											jQuery(this).parents('.counter_wrapper').find('.stat_count').html(show_data);
										}
									});	
									jQuery(this).addClass('done');
									jQuery(this).find('.stat_count');
								}							
							} else {
								jQuery(this).waypoint(function(){
									if (!jQuery(this).hasClass('done')) {
										var set_count = jQuery(this).find('.stat_count').attr('data-count');
										jQuery(this).find('.stat_temp').stop().animate({width: set_count}, {duration: 3000, step: function(now) {												
											var data = Math.floor(now),
											text_data = data.toString(),
											cut_data = '',
											cut_data2 = '';
											if (text_data.length > 3 && text_data.length < 7) {
												cut_data = text_data.substr(-3);
												cut_data2 = text_data.substr(0, text_data.length-3);
												show_data = cut_data2 + ' ' + cut_data;
											} 
											if (text_data.length > 6 && text_data.length < 10) {
												cut_data = text_data.substr(-3);
												if (text_data.length == 9) {
													cut_data1 = text_data.substr(text_data.length-6, text_data.length-6);
												} else if (text_data.length == 8) {
													cut_data1 = text_data.substr(text_data.length-6, text_data.length-5);
												} else {
													cut_data1 = text_data.substr(text_data.length-6, text_data.length-4);												
												}
												cut_data2 = text_data.substr(0, text_data.length-6);
												console.log('length: '+text_data.length +';'+cut_data2 +';'+ cut_data1 +';'+ cut_data);
												show_data = cut_data2 + ' ' + cut_data1 + ' ' + cut_data;												
											} 
											if (text_data.length < 4) {												
												show_data = text_data.substr(-3);
											}
											jQuery(this).parents('.counter_wrapper').find('.stat_count').html(show_data);
											}
										});	
										jQuery(this).addClass('done');
										jQuery(this).find('.stat_count');
									}
								},{offset: 'bottom-in-view'});								
							}														
						});
					} else {
						jQuery('.shortcode_counter').each(function(){							
							var set_count = jQuery(this).find('.stat_count').attr('data-count');
							jQuery(this).find('.stat_temp').animate({width: set_count}, {duration: 3000, step: function(now) {
									var data = Math.floor(now),
									text_data = data.toString(),
									cut_data = '',
									cut_data2 = '';
									if (text_data.length > 3 && text_data.length < 7) {
										cut_data = text_data.substr(-3);
										cut_data2 = text_data.substr(0, text_data.length-3);
										show_data = cut_data2 + ' ' + cut_data;
									} 
									if (text_data.length > 6 && text_data.length < 10) {
										cut_data = text_data.substr(-3);
										if (text_data.length == 9) {
											cut_data1 = text_data.substr(text_data.length-6, text_data.length-6);
										} else if (text_data.length == 8) {
											cut_data1 = text_data.substr(text_data.length-6, text_data.length-5);
										} else {
											cut_data1 = text_data.substr(text_data.length-6, text_data.length-4);												
										}
										cut_data2 = text_data.substr(0, text_data.length-6);
										console.log('length: '+text_data.length +';'+cut_data2 +';'+ cut_data1 +';'+ cut_data);
										show_data = cut_data2 + ' ' + cut_data1 + ' ' + cut_data;												
									} 
									if (text_data.length < 4) {												
										show_data = text_data.substr(-3);
									}
									jQuery(this).parents('.counter_wrapper').find('.stat_count').html(show_data);
								}
							});
							jQuery(this).find('.stat_count');
						},{offset: 'bottom-in-view'});	
					}
				});
			</script>
			";
				
			return $compile;
		}
		add_shortcode($shortcodeName, 'shortcode_counter');
	}
}

#Shortcode name
$shortcodeName="counter";
#Register shortcode & set parameters
$counter = new counter_shortcode();
$counter->register_shortcode($shortcodeName);

?>