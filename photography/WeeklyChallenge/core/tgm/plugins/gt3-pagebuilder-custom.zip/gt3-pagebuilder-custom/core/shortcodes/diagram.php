<?php

#diagramm_item
function diagramm_item($atts, $content = null)
{
    if (!isset($compile)) {$compile='';}

    extract(shortcode_atts(array(
        'heading_alignment' => 'left',
        'heading_size' => $GLOBALS["pbconfig"]['default_heading_in_module'],
        'heading_color' => '',
        'heading_text' => '',
		'diag_width' => '',
		'diag_title' => '',
        'percent' => '10',
    ), $atts));

	wp_enqueue_script('gt3_waypoint_js', get_template_directory_uri() . '/js/waypoint.js', array(), false, true);
	
	$percent2 = 100 - (int)$percent;
    $compile .= '
	<li class="skill_li">
		<div class="skill_wrapper">
			<div class="skill_item">
				<h6 class="skill_label">'.$diag_title.'</h6>
			</div>
			<div class="skill_bar_wrapper">
				<div class="skill_bar" data-width="'.$percent.'"></div>
				<span class="skill_title" style="right:' . $percent2 . '%">'.$percent.'%</span>
			</div>
		</div>
	</li>';
	
    return $compile;
}

add_shortcode('diagramm_item', 'diagramm_item');


class diagramm_shortcode
{

    public function register_shortcode($shortcodeName)
    {
        function shortcode_diagramm_shortcode($atts, $content = null)
        {
            if (!isset($compile)) {$compile='';}

            extract(shortcode_atts(array(
                'heading_alignment' => 'left',
                'heading_size' => $GLOBALS["pbconfig"]['default_heading_in_module'],
                'heading_color' => '',
                'heading_text' => '',
				'diagram_bg' => '#161616',
				'diagram_color' => '#161616',
				'bar_width' => '6px',
				'diagram_size' => '70px',
				'percent_size' => '14px',				
                'title' => '',
                'expanded_state' => '',
            ), $atts));

            #heading
            if (strlen($heading_color) > 0) {
                $custom_color = "color:#{$heading_color};";
            }
            if (strlen($heading_text) > 0) {
                $compile .= "<div class='bg_title'><" . $heading_size . " style='" . (isset($custom_color) ? $custom_color : '') . ((strlen($heading_alignment) > 0 && $heading_alignment !== 'left') ? 'text-align:'.$heading_alignment.';' : '') . "' class='headInModule'>{$heading_text}</" . $heading_size . "></div>";
            }
			$bar_width_wrapper = substr($bar_width, 0, -2);
			$bar_width_wrapper = (int)$bar_width_wrapper + 3;
			$bar_width_wrapper = $bar_width_wrapper . "px";
			
            $compile .= "
			<style>
				.module_diagramm .skill_bar_wrapper {
					height:".$bar_width_wrapper.";
				}
				.module_diagramm .skill_bar {
					height:".$bar_width.";
					position:absolute;
					background:".$diagram_bg.";
				}
			</style>
                <div class='shortcode_diagramm_shortcode diagramm'><ul class='skills_list' data-bg='".$diagram_bg."' data-color='".$diagram_bg."' data-width='".$bar_width."'>" . do_shortcode($content) . "</ul><div class='clear'></div></div>";

            $GLOBALS['showOnlyOneTimeJS']['chart_js'] = "
			<script>
				jQuery(document).ready(function($) {
					if (myWindow.width() > 760) {
						jQuery('.skill_li').waypoint(function(){							
							jQuery('.skill_bar').each(function(){
								jQuery(this).css('width', jQuery(this).attr('data-width')+'%');
							});
						},{offset: 'bottom-in-view'});
					} else {
						jQuery('.skill_bar').each(function(){
							jQuery(this).css('width', jQuery(this).attr('data-width')+'%');
						});
					}
				});
			</script>
			";

            return $compile;
        }

        add_shortcode($shortcodeName, 'shortcode_diagramm_shortcode');
    }
}


#Shortcode name
$shortcodeName = "diagramm";
$diagramm_shortcode = new diagramm_shortcode();
$diagramm_shortcode->register_shortcode($shortcodeName);

?>